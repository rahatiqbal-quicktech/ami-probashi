import 'package:flutter/material.dart';

const Color themeColor = Color.fromARGB(255, 82, 139, 106);
Color buttonColor = const Color.fromARGB(255, 61, 89, 114);
Color scaffoldBackground = Color.fromARGB(255, 229, 226, 226);
